Controls
	WASD 			-> Moves your character
	Space 			-> Jump
	1-8 			-> Select hotbar
	Scroll wheel 		-> Cycle hotbar
	E			-> Use cookingstands, chests and more
	O 			-> Display FPS counter
	Escape 			-> Open menu/pause game
	B/TAB			-> Open/close bag & crafting menucrafting menu
	R			-> Rotates buildable objects
	Shift			-> Sprint while moving

	When holding a building hammer:
	Hold right mouse button -> Opens build menu
	Left mouse button 	-> Place building

	When holding a hook:
	Hold left mouse button 	-> Charge throw

	When hook is in water:
	Hold left mouse button	-> Drag hook towards you
	Click right mouse button-> Abort/Instantly recieve hook to hand

	When holding a fishingrod:
	Hold left mouse button	-> Charge throw
	Click left mouse button -> Pull fish from water

	When holding an food or water:
	Click left mouse button -> Drink/eat

	When holding a axe:
	Hold left mouse button -> Desrtoy build objects / cut palm tree


Saving the game
	Saving can be done by either exiting to the main menu or by exiting the game.
	Saved files can later on be found in the main menu.
	